package com.example.av2mobile.location;

import android.location.Location;

public interface LocationConsumer {
    void currentLocation(Location location);
}
